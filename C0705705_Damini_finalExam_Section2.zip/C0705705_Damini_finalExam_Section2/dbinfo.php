<?php

	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "";

	//Create connection

	$conn = new mysqli($servername,$username,$password);

	// Check connection

	if ($conn->connect_error)
	{
		die("connection failed:" . $conn->connect_error);
	}
	else
	{
		echo "connection successful<br>";
	}

	$sql = "CREATE DATABASE if not exists C0705705_Dami";
	if ($conn->query($sql)===FALSE)
	{
		echo "Error creating database:" . $conn->error;
	}
	else
	{
		echo "Datebase created successfully. <br>";
	}

	$sql = "Use C0705705_Dami";
	if ($conn->query($sql)=== TRUE)
	{

	$sql = "CREATE TABLE if not exists login("
."userid int(10) NOT NULL AUTO_INCREMENT primary kEY,"
."username varchar(60) NOT NULL,"
."password varchar(60) NOT NULL,"
."repassword varchar(60) NOT NULL)";

if ($conn->query($sql)===TRUE)
		{
			echo "Table created successfully. <br>";
		}
		else
		{
			echo "Error creating Table :" . $conn->error;
		}

}
	else
	{
		echo "Error connecting database:" . $conn->error. "<br>";
	}


	// INsert into login

	"INSERT INTO login (username, password,repassword) VALUES
('admin', 'admin','admin'),
('damini', 'damini','damini'),
('chaitali', 'patel','patel'),
('admin', 'admin@123','admin@123');";
