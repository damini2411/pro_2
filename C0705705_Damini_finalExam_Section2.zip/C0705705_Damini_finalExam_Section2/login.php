<?php

(include 'dbinfo.php');
$servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "";

  //Create connection

  $conn = new mysqli($servername,$username,$password);

  // Check connection

  if ($conn->connect_error)
  {
    die("connection failed:" . $conn->connect_error);
  }
  else
  {
    echo "connection successful<br>";
  }

// $sql = "SELECT username as UserID, password as Password FROM login;";
// // $result = mysqli_query($admin->conn, $sql);
// $result = $conn->query($sql);
// //echo $result;
// if (mysql_num_rows($result) > 0) 
// {
// $totalRecords=mysql_num_rows($result);
// }

//$row = mysql_fetch_array($result);

if (isset($_REQUEST['user']) &&isset($_REQUEST['pswd'])) 
{
          
                $username = $_POST['user'];
                $password = $_POST['pswd'];


              $query = "SELECT * FROM login WHERE username='$username' AND password='$password'";
                $result = mysql_query($query)or die(mysql_error());
                $num_row = mysql_num_rows($result);
                  $row=mysql_fetch_array($result);
                  if( $num_row > 0 ) 
                  {
                    // header('location:Home.php');


                echo "<script type='text/javascript'>alert('Sucess');
                window.location.href='index.php';
                </script>";
                  }
                  else
                  {


                  echo "<script type='text/javascript'>alert('failed');
                  </script>";
                  } 
                //<div class="alert alert-danger">Access Denied</div>   
   }              

?>
<!DOCTYPE HTML>
<html>
<head>
<title>Modern an Admin Panel Category Flat Bootstarp Resposive Website Template | Login :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Modern Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
 <!-- Bootstrap Core CSS
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery-->
<script src="js/jquery.min.js"></script>
<!----webfonts
<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900' rel='stylesheet' type='text/css'>
<!---//webfonts--->  
<!-- Bootstrap Core JavaScript--> 
<script src="js/bootstrap.min.js"></script>
</head>
<body id="login">
  <div class="login-logo">
    <a href="index.html"><img src="images/logo.png" alt=""/></a>
  </div>
  <h2 class="form-heading">login</h2>
  <div class="app-cam">
	  <form action="" method="POST">
		<input type="text" class="text" value="UserID" name="user" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'E-mail address';}">
		<input type="password" value="Password" name="pswd" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Password';}">
		<div class="submit"><input type="submit" onclick="myFunction()" value="Login"></div>
		
		
			<div class="clearfix"></div>
		</ul>
	</form>
  </div>
   
</body>
</html>
